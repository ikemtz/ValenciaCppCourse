#pragma once
#include "pch.h"

struct Coordinate
{
	int x;
	int y;
};